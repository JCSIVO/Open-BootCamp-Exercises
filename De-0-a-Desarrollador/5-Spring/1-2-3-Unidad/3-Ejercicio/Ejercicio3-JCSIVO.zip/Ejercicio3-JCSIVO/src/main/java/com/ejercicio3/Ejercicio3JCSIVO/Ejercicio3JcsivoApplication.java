package com.ejercicio3.Ejercicio3JCSIVO;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio3JcsivoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio3JcsivoApplication.class, args);
	}

}
