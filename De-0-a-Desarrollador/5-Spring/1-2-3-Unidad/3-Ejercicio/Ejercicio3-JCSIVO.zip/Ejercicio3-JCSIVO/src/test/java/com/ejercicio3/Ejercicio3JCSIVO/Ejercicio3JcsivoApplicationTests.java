package com.ejercicio3.Ejercicio3JCSIVO;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio3JcsivoApplicationTests {

	@Test
	void contextLoads() {
	}

}
